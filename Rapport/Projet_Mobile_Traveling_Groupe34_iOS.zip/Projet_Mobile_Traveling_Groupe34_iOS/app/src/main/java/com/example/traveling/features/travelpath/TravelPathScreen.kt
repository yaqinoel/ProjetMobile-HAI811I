package com.example.traveling.features.travelpath

import androidx.compose.runtime.*
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel

/** TravelPathScreen — Point d'entrée principal du module Parcours */
@Composable
fun TravelPathScreen(
    isAnonymous: Boolean = false,
    initialDestination: String? = null,
    travelViewModel: TravelViewModel = viewModel()
) {
    val step by travelViewModel.currentStep.collectAsState()
    val selectedRouteId by travelViewModel.currentRouteId.collectAsState()

    when {
        step == "detail" && selectedRouteId != null -> {
            RouteDetailScreen(
                routeId = selectedRouteId!!,
                onBack = {
                    travelViewModel.setCurrentRouteId(null)
                    travelViewModel.setStep("results")
                }
            )
        }
        step == "loading" -> LoadingScreen()
        step == "results" -> ResultsScreen(
            travelViewModel = travelViewModel,
            onBack = { travelViewModel.setStep("preferences") },
            onViewDetail = { id ->
                travelViewModel.selectRoute(id)
                travelViewModel.setCurrentRouteId(id)
                travelViewModel.setStep("detail")
            }
        )
        else -> PreferencesForm(
            initialDestination = initialDestination,
            travelViewModel = travelViewModel,
            onGenerate = {
                travelViewModel.setStep("loading")
            },
            onLoadingComplete = { travelViewModel.setStep("results") }
        )
    }

    // Auto-transition from loading to results
    if (step == "loading") {
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(1800)
            travelViewModel.setStep("results")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TravelPathScreenPreview() {
    TravelPathScreen(
        isAnonymous = false,
        initialDestination = null
    )
}